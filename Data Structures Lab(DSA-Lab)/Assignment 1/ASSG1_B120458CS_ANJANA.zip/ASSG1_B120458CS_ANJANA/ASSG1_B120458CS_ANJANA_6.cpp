#include <iostream>
using namespace std;
/*Write a program to create a union with the following Fields.
1: height : float
2: age: int
The program should ask for the gender(F/M). If input gender is female, the program should
ask for the height and store it in the union. If input gender is male, the program should ask
for the age and store it in the union. Print both the values*/
 
union detail{
    float height;
    int age;
    }d;
int main()
{
   cout<<"Enter your gender(F/M) : ";
   char gender;
   cin>>gender;
   switch(gender)
   {
        case 'F' : cout<<"Enter your Height : ";
                   cin>>d.height;
                   break;
	case 'f' : cout<<"Enter your Height : ";
                   cin>>d.height;
                   break;
        case 'M' : cout<<"Enter your Age : ";
                   cin>>d.age;
                   break;
	case 'm' : cout<<"Enter your Age : ";
                   cin>>d.age;
                   break;
        default  : cout<<"Wrong Choice...\n";
    }
    cout<<"Height = "<<d.height;
    cout<<"\nAge = "<<d.age;
    cout<<endl;
    return 0;
}
