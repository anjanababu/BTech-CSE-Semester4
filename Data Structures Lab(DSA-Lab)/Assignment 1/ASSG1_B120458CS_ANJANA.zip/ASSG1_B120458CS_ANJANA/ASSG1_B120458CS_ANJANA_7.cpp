#include <iostream>
using namespace std;
/*Write a program to calculate sum and dierence of two integers using two functions. The
program should ask for a choice and based on choice, corresponding function should be called
using a function pointer.*/
int sum(int a,int b);
int difference(int a,int b);
int main()
{
    cout<<"\nEnter 2 numbers\n";
    int a,b,ch;
    int (*p1)(int ,int );
    cin>>a>>b;
    cout<<"Enter your choice\n";
    cout<<"1 : Sum\n";
    cout<<"2 : Difference\n";
    cin>>ch;
    switch(ch)
    {
        case 1 :{cout<<"Selected operation is Sum and the result is ";
		p1=sum;
		cout<<(*p1)(a,b)<<endl;
                break;}
        case 2 :{cout<<"Selected operation is Sum and the result is ";
		p1=difference;
		cout<<(*p1)(a,b)<<endl;
                break;}
       default :cout<<"Wrong Choice....\n";
    }
    cout<<endl;
    return 0;
}
int sum(int a,int b)
{
    return (a+b);
}
int difference(int a,int b)
{
    return (a-b);
}
