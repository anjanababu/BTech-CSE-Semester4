#include<iostream>
#include<string.h>
#include<stdio.h>
using namespace std;
/*Given two strings, say s1 and s2, write a program to concatenate the two strings. The final
string is to be stored as s1, and should have the contents of given s1 followed by s2. The
program must use pointers to access the strings.*/
void getString(char *p);
void printString(char *p);
void concat(char *p1,char *p2);
int main()
{
	char s1[200],s2[200];
	char *p1,*p2;
	p1=s1,p2=s2;
	cout<<"Enter first string : ";
	getString(p1);
	cout<<"Enter second string : ";
	getString(p2);
	p1=p1+strlen(s1);	
	concat(p1,p2);
	p1=s1;
	printString(p1);
	return 0;
	
}
void getString(char *p)
{
	char ch;
	while(1)
	{
		ch=getchar();
		if(ch=='\n')
			break;
		else
			*p=ch;
		p++;
	}
	*p='\0';
}
void printString(char *p)
{
	while(*p!='\0')
	{
		cout<<*p;
	        p++;
	}
	cout<<endl;
}
void concat(char *p1,char *p2)
{
	while(*p2!='\0')
	{
		*p1=*p2;
		p1++,p2++;
	}
	*p1='\0';
}
