#include<iostream>
#include<string.h>
#include<stdio.h>
using namespace std;
/*Given a word str and a paragraph, write a program to find the total number of occurrences of
str in the given paragraph.
Note : str will consist only of letters from the English alphabet [a-zA-Z]*/
int main()
{
cout<<"Enter the word : ";
char str[100];
gets(str);
cout<<"Enter the paragraph\n";
char para[1000];
int i=0;
char ch;
while(1)
{
ch=getchar();
if(ch=='\n')
	break;
else 
	para[i]=ch;
i++;
}
para[i]='\0';
i=0;
int count=0;
int len=strlen(str);
int l=0,w=0;
while(para[i]!='\0')
{
	if(w==len)
	{
		if(para[i]==' ' || para[i]=='.')
		{
			count++;			
		}
		else
			while(para[i]!=' ' || para[i]=='.')
				i++;
		w=0;
	}
	else
	{
		if(str[w]==para[i])
			w++;
		else if(para[i]=='.' || para[i]==' ')
			w=0;
		else if(str[w]>='a' && str[w]<='z')
		{
 			if(para[i]>='A' && para[i]<='Z')
					if(para[i]==str[w]-32)
						w++;
					else
						w=0;
		}
		else if(str[w]>='A' && str[w]<='Z')
	        {
			if(para[i]>='a' && para[i]<='z')
					if(para[i]==str[w]+32)
						w++;
					else
						w=0;	
		}
		
		if(w==0)
		{
			while(para[i]!=' ' &&  para[i]!='.')
			{ 
				++i;
			}
		}
	}
	i++;
}
cout<<"Occurence(case insensitive) = ";
if (w==len)
	cout<<++count<<endl;
else
	cout<<count<<endl;
return 0;
}
