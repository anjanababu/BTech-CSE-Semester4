#include<iostream>
#include<stdio.h>
#include<string.h>
#include<fstream>
/*Given a file name(or path) fname and two other strings s1 and s2, write a program to find
all occurrences of s1 in the file fname and replace all of them with s2. s1 and s2 can contain
letters from the English alphabet [a-zA-Z] or digits [0-9]. The file may contain space, comma,
period, and other exclamation marks in addition to words and numbers.*/
using namespace std;
int i;
void getString(char s[50]);
int main()
{
 char r[50],b[50],sub[50],ch;
 cout<<"Enter 2 strings(for case sensitive replacement)\n";
 cout<<"Replace : ";
 getString(r);
 cout<<"(replace exactly)By : ";
 getString(b);
 int len1=strlen(r);
 int len2=strlen(b);
 int j,l=0,flag=0,k=0;
 cout<<"Enter the filename : ";
 char fname[30];
 gets(fname);
 ifstream myfile1(fname);//opened abc.txt to read
 if(myfile1.good()) 		
 {
 ofstream myfile2("xyz.txt");//opened xyz.txt to write
 ch=myfile1.get();
 while(myfile1.good())
 {
        i=0;flag=1;
	char *sub=new char[50];
	for(i=0;((ch>='a' && ch<='z') || (ch>='A' && ch<='Z') || (ch>='0' && ch<='9')) && myfile1.good();i++)
	{
		sub[i]=ch;
		ch=myfile1.get();
	}

	if(len1==i)
	{
		for(k=0;k<len1;k++)
			if(sub[k]==r[k])
				flag==1;
			else if(r[k]>='a' && r[k]<='z')
				if(sub[k]>='A' && sub[k]<='Z')
					if(sub[k]==r[k]-32)
						flag=1;
					else
					{
						flag=0;k=len1;
					}
				else
				{
					flag=0;break;
				}	
			else if(r[k]>='A' && r[k]<='Z')
				if(sub[k]>='a' && sub[k]<='z')
					if(sub[k]==r[k]+32)
						flag=1;
					else
					{
						flag=0;k=len1;
					}
				else
				{
					flag=0;break;
				}	
			else
			{
				flag=0;break;
			}	
	}	
	else
		flag=0;

	if(flag==0)//not equal
		for(j=0;j<i;j++)
			myfile2<<sub[j];
	else
		for(j=0;j<len2;j++)
			myfile2<<b[j];

	if(ch!=EOF)
		myfile2<<ch;
	ch=myfile1.get();
	delete[] sub;
 }
 myfile1.close();//closed fname
 myfile2.close();//closed xyz.txt
 remove(fname);
 rename("xyz.txt",fname);
 }
 else
	cout<<"\nFile cannot be read\n";
 return 0;
}
void getString(char s[50])
{
i=0;
char ch;
while(1)
{
ch=getchar();
if(ch=='\n')
	break;
else
	s[i]=ch;
i++;
}
s[i]='\0';
}

