#include <iostream>
using namespace std;
//Given a positive integer n, write a program to Find all the distinct prime factors of n.
int prime(int a);
int main()
{
    cout<<"\nEnter the number n\n";
    int n,i;
    cin>>n;
    if(n<2)
        cout<<"No prime factors!!\n";
    else if(n==2)
        cout<<n<<" ";
    else
        for(i=2;i<=n;i++)
            if(n%i==0 && prime(i))
                cout<<i<<" ";
    cout<<endl;
    return 0;
}
int prime(int a)
{
    int j;
    if(a==2)
        return 1;
    else
        for(j=2;j<a;j++)
            if(a%j==0)
                return 0;
    return 1;
}
