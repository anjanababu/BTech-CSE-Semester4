#include <stdio.h>
//Given an array of integers, write a C program to reverse the array in-place using recursion.
int i;
int getArray(int a[100],int n);
int printArray(int a[100],int n);
int reverseArray(int a[100],int n,int i);

int main()
{
    printf("Enter the value of n \n");
    int n;
    scanf("%d",&n);
    int a[100];
    getArray(a,n);
    printf("Original Array\n");
    printArray(a,n);
    reverseArray(a,n,0);
    printf("\nFinal Array\n");
    printArray(a,n);
    printf("\n");
    return 0;
}
int getArray(int a[100],int n)
{
    printf("Enter the Elements of the array\n");
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
}
int printArray(int a[100],int n)
{
    for(i=0;i<n;i++)
        printf("%d ",a[i]);
}
int reverseArray(int a[100],int n,int i)
{
    int temp=0;
    if(i<(n/2))
    {
        temp=a[i];
        a[i]=a[n-i-1];
        a[n-i-1]=temp;
        reverseArray(a,n,i+1);
    }
    else
        return a[100];
}
